// Portal de Autos — EL DE FIAR
// React app: hero, filters, grid, inline-expanding cards, tweaks panel

const { useState, useEffect, useMemo, useRef } = React;

const INVENTORY = window.INVENTORY;

// =========================================================================
// TWEAKS
// =========================================================================
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "naranja"
}/*EDITMODE-END*/;

// =========================================================================
// ICONS — minimal inline SVG (Lucide-flavored)
// =========================================================================
const Icon = {
  Search: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>
    </svg>
  ),
  MapPin: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>
    </svg>
  ),
  Camera: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M14.5 4h-5L8 6H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-4l-1.5-2Z"/><circle cx="12" cy="13" r="3.5"/>
    </svg>
  ),
  X: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="m6 6 12 12M6 18 18 6"/>
    </svg>
  ),
  WhatsApp: (p) => (
    <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
      <path d="M17.5 14.4c-.3-.1-1.7-.9-2-1-.3-.1-.5-.2-.7.1-.2.3-.7 1-.9 1.2-.2.2-.3.2-.6.1-.3-.1-1.2-.4-2.3-1.4-.9-.8-1.5-1.7-1.6-2-.2-.3 0-.5.1-.6.1-.1.3-.3.4-.5.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5 0-.1-.7-1.7-.9-2.3-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.1.2 2.1 3.3 5.2 4.6.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.7-.7 1.9-1.4.2-.7.2-1.2.2-1.4-.1-.1-.3-.2-.6-.4ZM12 2C6.5 2 2 6.5 2 12c0 1.8.5 3.5 1.3 4.9L2 22l5.2-1.3c1.4.8 3 1.2 4.8 1.2 5.5 0 10-4.5 10-10S17.5 2 12 2Z"/>
    </svg>
  ),
  Calendar: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>
    </svg>
  ),
  ArrowRight: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M5 12h14M13 5l7 7-7 7"/>
    </svg>
  ),
  Plus: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M12 5v14M5 12h14"/>
    </svg>
  ),
  Info: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <circle cx="12" cy="12" r="9"/><path d="M12 8v.01M11 12h1v4h1"/>
    </svg>
  ),
};

// =========================================================================
// HELPERS
// =========================================================================
const fmtMXN = (n) => new Intl.NumberFormat('es-MX', { maximumFractionDigits: 0 }).format(n);
const phoneE164 = "525532779535"; // +52 55 3277 9535

const buildWA = (car) => {
  const msg = encodeURIComponent(
    `Hola, me interesa el ${car.marca} ${car.modelo} ${car.anio} publicado en su portal (ubicado en ${car.ubicacion}). Me gustaría agendar una cita para verlo.`
  );
  return `https://wa.me/${phoneE164}?text=${msg}`;
};

// =========================================================================
// NAV
// =========================================================================
function Nav({ heroMode }) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav className={`nav ${scrolled ? "scrolled" : ""} ${!scrolled && heroMode ? "hero-mode" : ""}`}>
      <div className="nav-inner">
        <div className="nav-logo">
          <img src="assets/logo-primary.png" alt="EL DE FIAR" className="img-dark" />
          <img src="assets/logo-white.svg" alt="EL DE FIAR" className="img-light" />
          <span className="nav-tag">Portal de autos</span>
        </div>
        <div className="nav-links">
          <button className="nav-link" onClick={() => document.getElementById("inventario").scrollIntoView({ behavior: "smooth", block: "start" })}>Inventario</button>
          <button className="nav-link" onClick={() => document.getElementById("proceso").scrollIntoView({ behavior: "smooth", block: "start" })}>Cómo funciona</button>
          <button className="nav-link" onClick={() => document.getElementById("contacto").scrollIntoView({ behavior: "smooth", block: "start" })}>Sucursales</button>
          <a className="nav-cta" href={`https://wa.me/${phoneE164}?text=${encodeURIComponent('Hola, me interesa agendar una cita en el portal de autos.')}`} target="_blank" rel="noopener noreferrer">
            Agendar cita <Icon.ArrowRight />
          </a>
        </div>
      </div>
    </nav>
  );
}

// =========================================================================
// HERO
// =========================================================================
function Hero({ total, cdmx, lerma }) {
  const [on, setOn] = useState(false);
  useEffect(() => { const t = setTimeout(() => setOn(true), 80); return () => clearTimeout(t); }, []);

  return (
    <section className="hero">
      <div className="hero-inner">
        <div>
          <div className="hero-eyebrow">
            <span className="dot"></span>
            Multimarca · CDMX & Lerma
          </div>
          <h1 className="hero-title">
            El auto correcto,{" "}
            <span className="accent">en tus manos</span>{" "}
            sin descapitalizarte.
          </h1>
          <p className="hero-sub">
            Una selección curada de unidades disponibles bajo arrendamiento o compra directa.
            Somos multimarca y cotizamos cualquier unidad. Atendemos bajo previa cita en nuestras dos ubicaciones.
          </p>
          <div className="hero-ctas">
            <button className="btn btn-primary" onClick={() => document.getElementById("inventario").scrollIntoView({ behavior: "smooth" })}>
              Ver inventario <Icon.ArrowRight />
            </button>
            <a className="btn btn-ghost-light" href={`https://wa.me/${phoneE164}?text=${encodeURIComponent('Hola, me interesa agendar una cita en el portal de autos.')}`} target="_blank" rel="noopener noreferrer">
              Agendar visita
            </a>
          </div>
        </div>

        <div className="hero-side">
          <div className="hero-stat">
            <span className="k orange">{String(total).padStart(2, "0")}</span>
            <span className="v">unidades en inventario, actualizado esta semana.</span>
          </div>
          <div className="hero-stat">
            <span className="k">{cdmx}</span>
            <span className="v">en CDMX · Av. Paseo de la Reforma 2654, Piso 12.</span>
          </div>
          <div className="hero-stat">
            <span className="k">{lerma}</span>
            <span className="v">en Lerma · Parque Industrial Lerma, Edo. Méx.</span>
          </div>
          <div className="hero-locations">
            <span><span className="pin"></span>CDMX</span>
            <span><span className="pin azul"></span>Lerma</span>
            <span>Bajo previa cita</span>
          </div>
        </div>
      </div>
    </section>
  );
}

// =========================================================================
// MARQUEE STRIP
// =========================================================================
function Strip() {
  const items = [
    "Arrendamiento puro", "Compra directa", "Sale & Lease Back",
    "Inventario curado", "Atención bajo previa cita", "CDMX · Lerma",
    "ISO 9001:2015", "ISO 31000:2018",
  ];
  const doubled = [...items, ...items];
  return (
    <div className="strip">
      <div className="strip-track">
        {doubled.map((t, i) => (
          <span key={i}>{t}<span className="sep"></span></span>
        ))}
      </div>
    </div>
  );
}

// =========================================================================
// FILTERS
// =========================================================================
function Filters({ q, setQ, loc, setLoc, max, setMax, totalShown, total, priceMin, priceMax }) {
  const onClear = () => { setQ(""); setLoc("todos"); setMax(priceMax); };
  const hasActive = q || loc !== "todos" || max < priceMax;

  return (
    <>
    <div className="filters">
      <div className="filters-head">
        <h2>Inventario <span className="italic">en venta</span></h2>
        <div className="meta">
          Mostrando <b>{String(totalShown).padStart(2, "0")}</b> de {String(total).padStart(2, "0")} unidades
        </div>
      </div>

      <div className="field">
        <label className="field-label">Buscar</label>
        <div className="field-input">
          <Icon.Search className="search-icon" />
          <input
            type="text" placeholder="Marca, modelo o color…"
            value={q} onChange={(e) => setQ(e.target.value)}
          />
        </div>
      </div>

      <div className="field">
        <label className="field-label">Ubicación</label>
        <div className="pill-group">
          {[
            { v: "todos", label: "Todos" },
            { v: "CDMX",  label: "CDMX" },
            { v: "Lerma", label: "Lerma" },
          ].map(opt => (
            <button key={opt.v} className={loc === opt.v ? "on" : ""} onClick={() => setLoc(opt.v)}>
              {opt.v !== "todos" && <span className="pin"></span>}
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      <div className="field">
        <label className="field-label">Precio máximo</label>
        <div className="range">
          <div className="range-row">
            <span>Hasta</span>
            <span><b>${fmtMXN(max)}</b> MXN</span>
          </div>
          <div className="range-track">
            <div className="range-fill" style={{ width: `${((max - priceMin) / (priceMax - priceMin)) * 100}%` }}></div>
            <input
              type="range" min={priceMin} max={priceMax} step={10000}
              value={max} onChange={(e) => setMax(Number(e.target.value))}
            />
          </div>
        </div>
      </div>

      <button className="filter-clear" onClick={onClear} disabled={!hasActive}
        style={hasActive ? {} : { opacity: 0.4, cursor: "not-allowed" }}>
        Limpiar
      </button>
    </div>

    <div className="chips">
      {q && <span className="chip">Búsqueda: "{q}"<button onClick={() => setQ("")}><Icon.X width="10" height="10" /></button></span>}
      {loc !== "todos" && <span className="chip">Ubicación: {loc}<button onClick={() => setLoc("todos")}><Icon.X width="10" height="10" /></button></span>}
      {max < priceMax && <span className="chip">Hasta ${fmtMXN(max)} MXN<button onClick={() => setMax(priceMax)}><Icon.X width="10" height="10" /></button></span>}
    </div>
    </>
  );
}

// =========================================================================
// CARD
// =========================================================================
function CarCard({ car, expanded, onToggle, onClose }) {
  const [photoIdx, setPhotoIdx] = useState(0);
  useEffect(() => { setPhotoIdx(0); }, [expanded]);

  const stateLabel = { disponible: "Disponible", apartado: "Apartado", vendido: "Vendido" }[car.estado];
  const isSold = car.estado === "vendido";

  return (
    <article
      className={`card ${expanded ? "expanded" : ""} ${isSold ? "sold" : ""} card-enter`}
      data-screen-label={`Card ${car.marca} ${car.modelo}`}
    >
      <div className="card-media" onClick={() => !isSold && (expanded ? onClose() : onToggle())}>
        <img src={car.fotos[photoIdx]} alt={`${car.marca} ${car.modelo} ${car.anio}`} loading="lazy" />
        <span className={`badge ${car.estado}`}>
          <span className="dot"></span>{stateLabel}
        </span>
        {!expanded && (
          <>
            <span className="loc-tag">
              <Icon.MapPin /> {car.ubicacion}
            </span>
            <span className="photo-count">
              <Icon.Camera /> {car.fotos.length}
            </span>
          </>
        )}
        {expanded && (
          <>
            <button className="exp-close" onClick={(e) => { e.stopPropagation(); onClose(); }} aria-label="Cerrar detalle">
              <Icon.X width="18" height="18" />
            </button>
            <div className="exp-thumbs">
              {car.fotos.map((p, i) => (
                <button key={i} className={i === photoIdx ? "on" : ""} onClick={(e) => { e.stopPropagation(); setPhotoIdx(i); }}>
                  <img src={p} alt="" />
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      <div className="card-body">
        {!expanded ? (
          <>
            <div className="card-head">
              <div>
                <h3 className="car-title">
                  {car.marca} {car.modelo}
                  <span className="year"> {car.anio}</span>
                </h3>
                <div className="car-sub">{car.transmision} · {car.combustible} · {fmtMXN(car.km)} km</div>
              </div>
            </div>
            <div className="price-row">
              <div className="price">
                ${fmtMXN(car.precio)}<span className="price-currency"> MXN</span>
              </div>
              <div className="monthly">
                Desde arrendamiento
                <b>${fmtMXN(car.mensualidad)} / mes</b>
              </div>
            </div>
            {!isSold && (
              <span className="tap-cta">
                Toca la imagen para ver detalle <Icon.Plus />
              </span>
            )}
          </>
        ) : (
          <div className="exp-row">
            <div>
              <div className="exp-eyebrow">{car.ubicacion} · {car.sucursal}</div>
              <h3 className="car-title">
                {car.marca} {car.modelo}
                <span className="year"> {car.anio}</span>
              </h3>
            </div>

            <p className="exp-desc">{car.descripcion}</p>

            <div className="exp-grid">
              <div className="row"><span className="k">Año</span><span className="v">{car.anio}</span></div>
              <div className="row"><span className="k">Kilometraje</span><span className="v">{fmtMXN(car.km)} km</span></div>
              <div className="row"><span className="k">Transmisión</span><span className="v">{car.transmision}</span></div>
              <div className="row"><span className="k">Combustible</span><span className="v">{car.combustible}</span></div>
              <div className="row"><span className="k">Color</span><span className="v">{car.color}</span></div>
              <div className="row"><span className="k">Estado</span><span className="v">{stateLabel}</span></div>
            </div>

            <div className="exp-price">
              <div className="col">
                <span className="k">Precio de contado</span>
                <span className="v">${fmtMXN(car.precio)}</span>
              </div>
              <div className="col monthly-col">
                <span className="k">Arrendamiento desde</span>
                <span className="v">${fmtMXN(car.mensualidad)}/mes</span>
                <span className="hint">Plazo 36 meses, sujeto a aprobación.</span>
              </div>
            </div>

            <div className="cita-note">
              <Icon.Calendar />
              <span>Las unidades se muestran <b>bajo previa cita</b> en nuestras sucursales de {car.ubicacion}.</span>
            </div>

            <div className="exp-actions">
              {!isSold ? (
                <>
                  <a className="btn-wa" href={buildWA(car)} target="_blank" rel="noopener noreferrer">
                    <Icon.WhatsApp /> Agendar cita por WhatsApp
                  </a>
                  <button className="btn-outline" onClick={onClose}>Cerrar detalle</button>
                </>
              ) : (
                <button className="btn-outline" onClick={onClose}>Cerrar detalle</button>
              )}
            </div>
          </div>
        )}
      </div>
    </article>
  );
}

// =========================================================================
// QUOTE-ANY CARD — "Somos multimarca, cotizamos cualquier unidad"
// =========================================================================
function QuoteAnyCard() {
  const waUrl = `https://wa.me/${phoneE164}?text=${encodeURIComponent('Hola, me interesa cotizar una unidad que no está en su portal. Quisiera platicar con un asesor.')}`;
  return (
    <article className="card card-quote card-enter">
      <div className="quote-grid">
        <div className="quote-eyebrow">
          <span className="dot"></span>
          Multimarca
        </div>
        <h3 className="quote-title">
          ¿No encontraste<br/>
          <span className="italic">la que buscas?</span>
        </h3>
        <p className="quote-sub">
          Cotizamos cualquier marca y modelo bajo arrendamiento o compra directa.
          Pásanos los datos de la unidad que tienes en mente y un asesor te contacta.
        </p>
        <a className="btn-wa" href={waUrl} target="_blank" rel="noopener noreferrer">
          <Icon.WhatsApp /> Cotizar mi unidad
        </a>
      </div>
    </article>
  );
}

// =========================================================================
// TRUST / PROCESS BLOCK
// =========================================================================
function Trust() {
  const [tipo, setTipo] = useState("pf");
  const [etapa, setEtapa] = useState("inicial");

  // Datos tomados literal de los checklists oficiales (CUM-FO-09, CUM-FO-10, CUM-FO-02 · REV:000 10/25 V1)
  const tipos = {
    pf: {
      label: "Persona Física",
      sub: "PF",
      ref: "CUM-FO-09 V1",
      desc: "Para empleado o profesionista que solicita el crédito a título personal.",
      stages: {
        inicial: [
          "Identificación oficial vigente",
          "7 últimos estados de cuenta",
          "Constancia de Situación Fiscal",
          "Consulta de buró de crédito con calificación SCORE",
          "Solicitud de crédito (formato PF)",
          "Solicitud de Consulta de Ekatena",
        ],
        aprobada: [
          "Comprobante de domicilio (no mayor a 3 meses)",
          "CURP",
          "Carátula de estado de cuenta para depósito de recursos, a nombre del acreditado",
        ],
        garantia: null,
      },
    },
    pfae: {
      label: "Persona Física con Actividad Empresarial",
      sub: "PFAE / PRAE",
      ref: "CUM-FO-10 V1",
      desc: "Para profesionistas independientes o dueños de negocio que facturan a nombre propio.",
      stages: {
        inicial: [
          "Identificación oficial vigente",
          "Constancia de Situación Fiscal (no mayor a 3 meses)",
          "Declaración anual y recibo de la misma · ejercicio 2024",
          "Solicitud de crédito (formato PRAE)",
          "Solicitud de Consulta de Ekatena",
          "Buró de crédito especial con calificación SCORE",
          "7 últimos estados de cuenta bancaria · todas las cuentas activas",
        ],
        aprobada: [
          "Comprobante de domicilio (no mayor a 3 meses)",
          "CURP",
          "Carátula de estado de cuenta para depósito de recursos, a nombre del acreditado",
          "Opinión de Cumplimiento (no mayor a 3 meses)",
        ],
        garantia: [
          "Escritura pública del inmueble inscrita en el Registro Público de la Propiedad (RPP)",
          "Boleta predial vigente y pagada",
          "Boleta de agua vigente y pagada",
          "Avalúo, plano catastral o croquis del inmueble (si existiera)",
          "Geolocalización de la garantía · ubicación exacta",
          "Identificación oficial del propietario",
          "Constancia de Situación Fiscal del propietario",
          "CURP del propietario",
          "Comprobante de domicilio del propietario",
          "Acta de matrimonio · si aplica régimen de sociedad conyugal",
          "ID oficial y CSF del cónyuge · si están por sociedad conyugal",
          "Certificado de Libertad de Gravamen (lo gestiona la notaría designada por la financiera tras aprobación)",
        ],
      },
    },
    pm: {
      label: "Persona Moral",
      sub: "PM",
      ref: "CUM-FO-02 V1",
      desc: "Para empresas que solicitan el crédito a nombre de la sociedad.",
      stages: {
        inicial: [
          "Solicitud de crédito (formato PM)",
          "Estados financieros 2024 y 2025 (no mayor a 3 meses)",
          "Declaración anual y recibo de la misma · ejercicio 2024",
          "Acta Constitutiva con inscripción en el Registro Público de la Propiedad (RPP)",
          "Poderes actualizados",
          "Solicitud de Consulta de Ekatena",
          "7 últimos estados de cuenta bancarios",
          "Consulta de buró de crédito especial con calificación SCORE",
          "Constancia de Situación Fiscal de la empresa (no mayor a 3 meses)",
          "Identificación oficial y comprobante de domicilio del representante legal",
          "Constancia de Situación Fiscal del representante legal (no mayor a 3 meses)",
        ],
        aprobada: [
          "Comprobante de domicilio fiscal de la empresa (no mayor a 3 meses)",
          "Formato de propietario real con identificación oficial del propietario real",
          "Formato de accionistas y funcionarios",
          "Opinión de Cumplimiento (no mayor a 3 meses)",
          "Declaración anual y recibo de la misma · ejercicio 2024",
        ],
        garantia: [
          "Escritura pública del inmueble inscrita en el Registro Público de la Propiedad (RPP)",
          "Boleta predial vigente y pagada",
          "Boleta de agua",
          "Avalúo, plano catastral o croquis del inmueble (si existiera)",
          "Geolocalización de la garantía",
          "Identificación oficial del propietario",
          "Constancia de Situación Fiscal del propietario",
          "CURP del propietario",
          "Comprobante de domicilio del propietario",
          "Acta de matrimonio · si aplica régimen de sociedad conyugal",
          "ID oficial y CSF del cónyuge · si están por sociedad conyugal",
          "Certificado de Libertad de Gravamen (lo gestiona la notaría designada por la financiera tras aprobación)",
        ],
      },
    },
  };

  const activo = tipos[tipo];
  const stages = activo.stages;
  // If user switches type while on a stage that doesn't exist, fall back to inicial
  const safeEtapa = stages[etapa] ? etapa : "inicial";
  const docs = stages[safeEtapa];

  const etapaLabels = {
    inicial:  "Inicial",
    aprobada: "Posterior a aprobación",
    garantia: "Garantía hipotecaria",
  };
  const etapaHints = {
    inicial:  "Reúne estos documentos para arrancar tu solicitud.",
    aprobada: "Una vez aprobada la solicitud, se requiere la siguiente información.",
    garantia: "Solo aplica si tu operación incluye garantía hipotecaria.",
  };

  return (
    <section className="trust" id="proceso">
      <div className="trust-inner">
        <div>
          <h3>
            Cómo funciona <span className="italic">comprar o arrendar</span> con nosotros.
          </h3>
          <p>
            Atención personalizada, sin filas y sin sorpresas. Cada unidad pasa por una revisión
            mecánica documentada antes de publicarse en el portal.
          </p>
        </div>

        <div className="steps">
          <div className="step">
            <div className="n">01</div>
            <div>
              <h4>Elige tu unidad en el portal.</h4>
              <p>Filtra por ubicación y rango de precio. Si tienes dudas sobre una unidad específica, escríbenos por WhatsApp.</p>
            </div>
          </div>
          <div className="step">
            <div className="n">02</div>
            <div>
              <h4>Agenda una cita.</h4>
              <p>Las unidades se muestran únicamente bajo previa cita. Confirmamos disponibilidad de la unidad y de un asesor que te acompañe.</p>
            </div>
          </div>
          <div className="step">
            <div className="n">03</div>
            <div>
              <h4>Conoce y prueba el auto.</h4>
              <p>Te recibimos en CDMX o Lerma para inspección visual y prueba de manejo. Revisamos documentación y bitácora de servicio contigo.</p>
            </div>
          </div>
          <div className="step">
            <div className="n">04</div>
            <div>
              <h4>Compra o arrenda sin descapitalizarte.</h4>
              <p>Te ofrecemos compra directa o esquemas de arrendamiento puro con plazos de 24 a 48 meses. Diagnóstico inicial sin compromiso.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="reqs">
        <div className="reqs-head">
          <div>
            <div className="reqs-eyebrow">
              <span className="dot"></span>
              Requerimientos · crédito
            </div>
            <h3>
              La documentación que <span className="italic">necesitamos</span> para empezar.
            </h3>
          </div>
          <p className="reqs-intro">
            Los requisitos cambian según quién solicita el crédito y la etapa de la operación.
            Elige tu caso para ver la lista exacta de documentos.
          </p>
        </div>

        <div className="reqs-tabs" role="tablist" aria-label="Tipo de solicitante">
          {Object.entries(tipos).map(([k, v]) => (
            <button
              key={k}
              role="tab"
              aria-selected={tipo === k}
              className={`reqs-tab ${tipo === k ? "on" : ""}`}
              onClick={() => setTipo(k)}
            >
              <span className="reqs-tab-sub">{v.sub}</span>
              <span className="reqs-tab-label">{v.label}</span>
            </button>
          ))}
        </div>

        <div className="reqs-stages" role="tablist" aria-label="Etapa">
          {["inicial", "aprobada", "garantia"].filter(s => stages[s]).map(s => (
            <button
              key={s}
              role="tab"
              aria-selected={safeEtapa === s}
              className={`reqs-stage ${safeEtapa === s ? "on" : ""}`}
              onClick={() => setEtapa(s)}
            >
              <span className="reqs-stage-count">{stages[s].length}</span>
              {etapaLabels[s]}
            </button>
          ))}
        </div>

        <div className="reqs-active-desc">
          <b>{etapaLabels[safeEtapa]}.</b> {etapaHints[safeEtapa]} <span className="ref">· Ref. {activo.ref}</span>
        </div>

        <div className="reqs-grid" key={`${tipo}-${safeEtapa}`}>
          {docs.map((d, i) => (
            <div className="req" key={i}>
              <div className="req-n">{String(i + 1).padStart(2, "0")}</div>
              <div>
                <h4>{d}</h4>
              </div>
            </div>
          ))}
        </div>

        <div className="reqs-foot">
          <p>
            <Icon.Info /> El expediente se entrega a tu asesor en la primera cita. Si tienes dudas
            sobre algún documento, pregúntanos por WhatsApp antes de tu visita.
          </p>
          <a
            className="btn-wa"
            href={`https://wa.me/${phoneE164}?text=${encodeURIComponent(`Hola, tengo dudas sobre los requerimientos de crédito para ${activo.sub} (${etapaLabels[safeEtapa]}) en el portal de autos.`)}`}
            target="_blank" rel="noopener noreferrer"
          >
            <Icon.WhatsApp /> Preguntar por WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}

  return (
    <section className="trust" id="proceso">
      <div className="trust-inner">
        <div>
          <h3>
            Cómo funciona <span className="italic">comprar o arrendar</span> con nosotros.
          </h3>
          <p>
            Atención personalizada, sin filas y sin sorpresas. Cada unidad pasa por una revisión
            mecánica documentada antes de publicarse en el portal.
          </p>
        </div>

        <div className="steps">
          <div className="step">
            <div className="n">01</div>
            <div>
              <h4>Elige tu unidad en el portal.</h4>
              <p>Filtra por ubicación y rango de precio. Si tienes dudas sobre una unidad específica, escríbenos por WhatsApp.</p>
            </div>
          </div>
          <div className="step">
            <div className="n">02</div>
            <div>
              <h4>Agenda una cita.</h4>
              <p>Las unidades se muestran únicamente bajo previa cita. Confirmamos disponibilidad de la unidad y de un asesor que te acompañe.</p>
            </div>
          </div>
          <div className="step">
            <div className="n">03</div>
            <div>
              <h4>Conoce y prueba el auto.</h4>
              <p>Te recibimos en CDMX o Lerma para inspección visual y prueba de manejo. Revisamos documentación y bitácora de servicio contigo.</p>
            </div>
          </div>
          <div className="step">
            <div className="n">04</div>
            <div>
              <h4>Compra o arrenda sin descapitalizarte.</h4>
              <p>Te ofrecemos compra directa o esquemas de arrendamiento puro con plazos de 24 a 48 meses. Diagnóstico inicial sin compromiso.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="reqs">
        <div className="reqs-head">
          <div>
            <div className="reqs-eyebrow">
              <span className="dot"></span>
              Requerimientos iniciales · crédito
            </div>
            <h3>
              La documentación que <span className="italic">necesitamos</span> para empezar.
            </h3>
          </div>
          <p className="reqs-intro">
            Los requisitos cambian ligeramente según quién solicita el crédito.
            Elige tu caso para ver la lista exacta de documentos que necesitas reunir.
          </p>
        </div>

        <div className="reqs-tabs" role="tablist">
          {Object.entries(tipos).map(([k, v]) => (
            <button
              key={k}
              role="tab"
              aria-selected={tipo === k}
              className={`reqs-tab ${tipo === k ? "on" : ""}`}
              onClick={() => setTipo(k)}
            >
              <span className="reqs-tab-sub">{v.sub}</span>
              <span className="reqs-tab-label">{v.label}</span>
            </button>
          ))}
        </div>

        <div className="reqs-active-desc">{activo.desc}</div>

        <div className="reqs-grid" key={tipo}>
          {activo.docs.map(r => (
            <div className="req" key={r.k}>
              <div className="req-n">{r.k}</div>
              <div>
                <h4>{r.t}</h4>
                <p>{r.d}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="reqs-foot">
          <p>
            <Icon.Info /> El expediente se entrega a tu asesor en la primera cita. Si tienes dudas
            sobre algún documento, pregúntanos por WhatsApp antes de tu visita.
          </p>
          <a
            className="btn-wa"
            href={`https://wa.me/${phoneE164}?text=${encodeURIComponent(`Hola, tengo dudas sobre los requerimientos de crédito para ${activo.sub} en el portal de autos.`)}`}
            target="_blank" rel="noopener noreferrer"
          >
            <Icon.WhatsApp /> Preguntar por WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}

// =========================================================================
// FOOTER
// =========================================================================
function Footer() {
  return (
    <footer className="footer" id="contacto">
      <div className="footer-inner">
        <div className="footer-brand">
          <img src="assets/logo-white.svg" alt="EL DE FIAR" />
          <p>
            Financiera integral mexicana. Liquidez para producir, crecer y cumplir tus metas
            sin descapitalizarte. SOFOM regulada · ISO 9001:2015 · ISO 31000:2018.
          </p>
          <div className="footer-contact">
            <a href={`tel:+${phoneE164}`}>
              <span className="k">Tel · WhatsApp</span>
              <span className="v">55 3277 9535</span>
            </a>
          </div>
        </div>

        <div className="footer-col">
          <h5>Sucursal CDMX</h5>
          <ul>
            <li><b>Av. Paseo de la Reforma 2654</b><small>Piso 12, Lomas Altas, CDMX</small></li>
            <li>L–V · 9:00 a 18:00</li>
            <li><small>Atención bajo previa cita</small></li>
          </ul>
        </div>

        <div className="footer-col">
          <h5>Sucursal Lerma</h5>
          <ul>
            <li><b>Parque Industrial Lerma</b><small>Lerma de Villada, Edo. México</small></li>
            <li>L–V · 9:00 a 17:00</li>
            <li><small>Atención bajo previa cita</small></li>
          </ul>
        </div>
      </div>

      <div className="footer-legal">
        <span>© 2026 EL DE FIAR SDLTS</span>
        <span>Portal de autos · v1.0</span>
      </div>
    </footer>
  );
}

// =========================================================================
// MAIN APP
// =========================================================================
function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply accent at root for CSS
  useEffect(() => {
    document.documentElement.setAttribute("data-accent", tweaks.accent);
  }, [tweaks.accent]);

  const priceMin = 200000;
  const priceMax = 700000;

  const [q, setQ] = useState("");
  const [loc, setLoc] = useState("todos");
  const [maxPrice, setMaxPrice] = useState(priceMax);
  const [expandedId, setExpandedId] = useState(null);

  const cdmxCount = INVENTORY.filter(c => c.ubicacion === "CDMX").length;
  const lermaCount = INVENTORY.filter(c => c.ubicacion === "Lerma").length;

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    return INVENTORY.filter(c => {
      if (term) {
        const hay = `${c.marca} ${c.modelo} ${c.color}`.toLowerCase();
        if (!hay.includes(term)) return false;
      }
      if (loc !== "todos" && c.ubicacion !== loc) return false;
      if (c.precio > maxPrice) return false;
      return true;
    });
  }, [q, loc, maxPrice]);

  // close expanded when filters hide it
  useEffect(() => {
    if (expandedId && !filtered.find(c => c.id === expandedId)) setExpandedId(null);
  }, [filtered, expandedId]);

  // ESC closes
  useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") setExpandedId(null); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <Nav heroMode={true} />
      <Hero total={INVENTORY.length} cdmx={cdmxCount} lerma={lermaCount} />
      <Strip />

      <main className="filters-wrap" id="inventario">
        <Filters
          q={q} setQ={setQ}
          loc={loc} setLoc={setLoc}
          max={maxPrice} setMax={setMaxPrice}
          totalShown={filtered.length}
          total={INVENTORY.length}
          priceMin={priceMin}
          priceMax={priceMax}
        />

        <div className="grid-wrap">
          <div className="grid">
            {filtered.length === 0 ? (
              <div className="no-results">
                <h4>Sin coincidencias</h4>
                <p>Ajusta los filtros para ver más unidades.</p>
              </div>
            ) : (
              <>
                {filtered.map(car => (
                  <CarCard
                    key={car.id}
                    car={car}
                    expanded={expandedId === car.id}
                    onToggle={() => setExpandedId(car.id)}
                    onClose={() => setExpandedId(null)}
                  />
                ))}
                <QuoteAnyCard />
              </>
            )}
          </div>
        </div>
      </main>

      <Trust />
      <Footer />

      <TweaksPanel title="Tweaks">
        <TweakSection label="Color de acento">
          <TweakRadio
            label="Acento"
            value={tweaks.accent}
            onChange={(v) => setTweak("accent", v)}
            options={[
              { value: "naranja", label: "Naranja" },
              { value: "azul",    label: "Azul" },
              { value: "mixto",   label: "Mixto" },
            ]}
          />
          <p style={{ margin: "10px 0 0", fontSize: 12, color: "#6A7286", lineHeight: 1.5 }}>
            Cambia el color de acento del CTA principal y otros toques.
            "Mixto" mantiene naranja en CTA y azul en links/headlines (recomendado).
          </p>
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
